package ce326.hw2;

import java.util.List;

public interface Movable {
    List<int[]> moveOptions(Board board);
}
