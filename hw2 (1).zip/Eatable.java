
package ce326.hw2;


public interface Eatable {
    public int eaten();
}
